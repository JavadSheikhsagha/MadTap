package ir.rayandish.clickfaster

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var paintView = findViewById<PaintView>(R.id.paintView);
        paintView.listener = object :PaintView.OnWinListener{
            override fun onWin(winner: Int) {
                sho(winner)
                paintView.refresh()
            }
        }
    }


    private fun sho(winner: Int) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_win)
        dialog.window!!.setBackgroundDrawable(
            ColorDrawable(Color.TRANSPARENT)
        )
//        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        //        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        val lp = WindowManager.LayoutParams()
        val window = dialog.window
        lp.copyFrom(window!!.attributes)
//        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        //        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        window!!.attributes = lp
        dialog.window!!.setGravity(Gravity.CENTER)
        val layout = dialog.findViewById(R.id.lly) as LinearLayout
        if(winner == 1){
            layout.setBackgroundResource(R.drawable.bg_dialog_blue)
        }else{
            layout.setBackgroundResource(R.drawable.bg_dialog)
        }
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()

    }
}